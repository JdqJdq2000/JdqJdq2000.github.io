// When the user scrolls in the browser window
$(window).on('scroll', function () {
	// Step 1: Google $(window).scrollTop();
	var distanceScrolled = $(window).scrollTop();

	// Step 2: Log distanceScrolled to the console to see what it holds!

  // if distanceScrolled is greater than or equal to 50
    // Add a class to the nav to update styles (give it a white background color)
  // else
    // Remove the class from the nav to remove the background color

		
});

// DOCUMENT EVENTS ==================================================
// When the user scrolls in the browser window (Hint: the selector is provided here)
$(window).on('yourEventHere', function () {
  // Add the .party class to the body
  // Fade in the image
  // Change the text for the h1 to "I'm ready!!"

});

// STEP 1: When the button is clicked, add the party class to the div.


// Test it out! Open your console to see errors if it's not working.
